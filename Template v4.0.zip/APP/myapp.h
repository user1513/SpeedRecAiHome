#ifndef _MYAPP_H
#define _MYAPP_H

#include "stdint.h"
#include "bsp.h"
uint8_t usart_parse(uint8_t * _ucpTmp);

void GetEspInfo(void);

#endif


