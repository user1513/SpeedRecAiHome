#ifndef _BSP_ENCODER_
#define _BSP_ENCODER_

#include "stm32f4xx.h" 
void bsp_encoder_init(void);

#endif

