#ifndef _BSP_USART_H
#define _BSP_USART_H

#include "bsp.h"

void bspUsartInit(uint32_t bound);

#endif

